"use strict";

const COLORS = ["#f36b21", "#1478a7", "#7b4cb4", "#16866b"];
const LEVEL_COUNT = 10;
const LEVEL_DISTANCE_KM = 1;
const LEVEL_NAMES = [
  "Woonwijk", "Schoolzone", "Brugroute", "Buitengebied", "Dorpskern",
  "Kanaalroute", "Werkgebied", "Parkroute", "Drukke kruising", "Finaleroute"
];
const PARTS = [
  { id:"voorwiel", label:"Voorwiel", instruction:"Pak het voorwiel en plaats het in de voorvork.", sprite:"c0 r0", pos:[77,65] },
  { id:"achterwiel", label:"Achterwiel", instruction:"Pak het achterwiel en plaats het in de achtervork.", sprite:"c0 r0", pos:[23,65] },
  { id:"zadel", label:"Zadel", instruction:"Zet het zadel op de zadelpen.", sprite:"c1 r0", pos:[36,18] },
  { id:"stuur", label:"Stuur", instruction:"Monteer het stuur boven de voorvork.", sprite:"c2 r0", pos:[70,17] },
  { id:"linkerpedaal", label:"Linkerpedaal", instruction:"Draai het linkerpedaal in de linker crank.", sprite:"c3 r0", pos:[44,61] },
  { id:"rechterpedaal", label:"Rechterpedaal", instruction:"Draai het rechterpedaal in de rechter crank.", sprite:"c3 r0", pos:[50,69] },
  { id:"ketting", label:"Ketting", instruction:"Leg de ketting om de tandwielen.", sprite:"c0 r1", pos:[34,70] },
  { id:"voorlamp", label:"Voorlamp", instruction:"Monteer de voorlamp bij de voorkant van het frame.", sprite:"c1 r1", pos:[72,32] }
];

// Deze vragen zijn bewust ongewijzigd gebleven.
const QUESTIONS = [
  { type:"VRAAG", q:"Hoe heet het onderdeel waarop je zit?", answers:["Bagagedrager","Zadel","Frame","Stuur"], correct:1, icon:"c1 r0", hint:"Je zit erop." },
  { type:"VRAAG", q:"Welk onderdeel brengt de kracht van de pedalen naar het achterwiel?", answers:["Ketting","Remkabel","Spaak","Voorvork"], correct:0, icon:"c0 r1", hint:"Dit metalen onderdeel loopt rond de tandwielen." },
  { type:"VRAAG", q:"Waarmee stuur je de fiets naar links en rechts?", answers:["Crank","Bagagedrager","Stuur","Spatbord"], correct:2, icon:"c2 r0", hint:"Je houdt dit met twee handen vast." },
  { type:"PECH", q:"Je band is zacht, maar niet lek. Wat gebruik je?", answers:["Schroevendraaier","Fietspomp","Steeksleutel","Plakset"], correct:1, icon:"c2 r1", hint:"Hiermee doe je lucht in de band." },
  { type:"PECH", q:"Je wilt een buitenband van de velg halen. Welk gereedschap kies je?", answers:["Bandenlichters","Hamer","Zaag","Inbussleutel"], correct:0, icon:"c0 r2", hint:"Gebruik geen schroevendraaier. Die kan de binnenband beschadigen." },
  { type:"PECH", q:"Je binnenband heeft een klein gaatje. Wat heb je nodig?", answers:["Smeerolie","Plakset","Moersleutel","Nieuwe ketting"], correct:1, icon:"c2 r2", hint:"Schuren, lijm aanbrengen en een plakker plaatsen." },
  { type:"VRAAG", q:"Hoe heet één dun metalen staafje in een wiel?", answers:["Spaak","As","Velg","Crank"], correct:0, icon:"c0 r0", hint:"Veel van deze staafjes verbinden de naaf met de velg." },
  { type:"PECH", q:"Een moer zit los. Welk gereedschap past het best?", answers:["Bandenlichter","Fietspomp","Steeksleutel","Plakset"], correct:2, icon:"c3 r1", hint:"Dit gereedschap past om een moer." },
  { type:"PECH", q:"Een kruiskopschroef van de lamp zit los. Wat kies je?", answers:["Schroevendraaier","Pomp","Bandenlichter","Plakset"], correct:0, icon:"c1 r2", hint:"Kies de kruiskop die goed in de schroef past." },
  { type:"VRAAG", q:"Welk onderdeel zorgt dat water niet tegen je kleding spat?", answers:["Spatbord","Kettingkast","Voorvork","Velg"], correct:0, icon:"c0 r0", hint:"Dit zit dicht boven de band." },
  { type:"VRAAG", q:"Wat knijp je in om te remmen?", answers:["Handvat","Bel","Remhendel","Pedaal"], correct:2, icon:"c2 r0", hint:"Dit zit bij je handen aan het stuur." },
  { type:"PECH", q:"De ketting piept en loopt stroef. Wat doe je eerst?", answers:["Band oppompen","Ketting reinigen en smeren","Zadel lager zetten","Lamp vervangen"], correct:1, icon:"c0 r1", hint:"Vuil eraf, daarna een klein beetje kettingolie." }
];

const state = {
  players: [], currentPlayer: 0, round: 1, sound: true,
  mountOrder: [], trayOrder: [], mounted: new Set(), selectedPart: null,
  buildStartedAt: 0, timerHandle: null, course: null, bike: null,
  raceStartedAt: 0, animation: null, lastFrame: 0, challenge: null,
  keys: new Set(), messageTimer: null, levelCourses: [], currentLevel: 0,
  lightPoints: 0, questionOrder: [], rearLightSelected: false, rearLightMounted: false
};

const routeBackground = typeof Image === "undefined" ? null : new Image();
if (routeBackground) {
  routeBackground.src = "assets/dutch-route-background.png";
  routeBackground.addEventListener("load", () => { if (state.bike) drawCourse(); });
}
const cyclistImage = typeof Image === "undefined" ? null : new Image();
if (cyclistImage) {
  cyclistImage.src = "assets/real-cyclist-top.png";
  cyclistImage.addEventListener("load", () => { if (state.bike) drawCourse(); });
}

const $ = id => document.getElementById(id);
const screens = ["setupScreen", "buildScreen", "approvalScreen", "raceScreen", "rearLightScreen", "betweenScreen", "resultsScreen"];

function showScreen(id, phase) {
  screens.forEach(name => $(name).classList.toggle("active", name === id));
  $("phasePill").textContent = phase;
  window.scrollTo({ top:0, behavior:"smooth" });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

function beep(kind="ok") {
  if (!state.sound) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = kind === "ok" ? "sine" : "sawtooth";
    osc.frequency.value = kind === "ok" ? 620 : 170;
    gain.gain.setValueAtTime(.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + .16);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + .17);
  } catch (_) {}
}

function formatTime(ms) {
  const total = Math.max(0, ms) / 1000;
  const min = Math.floor(total / 60);
  const sec = Math.floor(total % 60);
  const tenth = Math.floor((total % 1) * 10);
  return `${String(min).padStart(2,"0")}:${String(sec).padStart(2,"0")}.${tenth}`;
}

function startTimer(getTime) {
  stopTimer();
  const update = () => { $("timer").textContent = formatTime(getTime()); };
  update();
  state.timerHandle = setInterval(update, 100);
}

function stopTimer() {
  clearInterval(state.timerHandle);
  state.timerHandle = null;
}

function mulberry32(seed) {
  return function() {
    let t = seed += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function shuffle(items, random=Math.random) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function renderPlayerInputs() {
  const wrap = $("playerInputs");
  wrap.innerHTML = "";
  state.players.forEach((p, i) => {
    const row = document.createElement("div");
    row.className = "player-row";
    row.innerHTML = `<span class="player-number" style="background:${COLORS[i]}">${i + 1}</span><input maxlength="18" autocomplete="off" aria-label="Naam speler ${i + 1}" placeholder="Naam speler ${i + 1}" value="${escapeHtml(p.name || "")}">${state.players.length > 2 ? '<button class="remove-player" type="button" aria-label="Verwijder speler">×</button>' : ""}`;
    row.querySelector("input").addEventListener("input", e => { state.players[i].name = e.target.value; });
    row.querySelector(".remove-player")?.addEventListener("click", () => { state.players.splice(i, 1); renderPlayerInputs(); });
    wrap.appendChild(row);
  });
  $("addPlayerBtn").disabled = state.players.length >= 4;
}

function addPlayer() {
  if (state.players.length >= 4) return;
  state.players.push({ name:"" });
  renderPlayerInputs();
  setTimeout(() => $("playerInputs").lastElementChild.querySelector("input").focus(), 0);
}

function startFromSignup() {
  const names = state.players.map(p => p.name.trim());
  if (names.some(name => !name)) {
    $("setupError").textContent = "Vul voor iedere speler een naam in.";
    return;
  }
  if (new Set(names.map(name => name.toLowerCase())).size !== names.length) {
    $("setupError").textContent = "Gebruik voor iedere speler een andere naam.";
    return;
  }
  beginRound(names);
}

function beginRound(names) {
  const seed = (Date.now() ^ (state.round * 2654435761)) >>> 0;
  state.levelCourses = Array.from({length:LEVEL_COUNT}, (_, index) => createCourse((seed + index * 104729) >>> 0, index));
  state.course = state.levelCourses[0];
  state.questionOrder = shuffle([...Array(QUESTIONS.length).keys()], mulberry32(seed ^ 0x9e3779b9));
  state.currentPlayer = 0;
  state.players = names.map((name, i) => ({
    name, color:COLORS[i], buildTime:0, raceTime:0, totalTime:0,
    buildPenalty:0, racePenalty:0, mistakes:0
  }));
  $("roundPill").textContent = `Ronde ${state.round}`;
  startBuildTurn();
}

function startBuildTurn() {
  const player = state.players[state.currentPlayer];
  const random = mulberry32((state.levelCourses[0].seed + (state.currentPlayer + 1) * 9176) >>> 0);
  state.mountOrder = shuffle(PARTS, random);
  state.trayOrder = shuffle(PARTS, random);
  state.mounted = new Set();
  state.selectedPart = null;
  player.buildPenalty = 0;
  state.buildStartedAt = performance.now();
  $("builderName").textContent = player.name;
  $("builderName").style.color = player.color;
  $("playerTurnNumber").textContent = `${state.currentPlayer + 1} VAN ${state.players.length}`;
  showScreen("buildScreen", "Monteren");
  startTimer(() => performance.now() - state.buildStartedAt + player.buildPenalty);
  renderBuild();
}

function renderBuild() {
  const current = state.mountOrder[state.mounted.size];
  $("buildCount").textContent = state.mounted.size;
  $("taskNumber").textContent = `Opdracht ${Math.min(state.mounted.size + 1, 8)}`;
  $("targetPart").textContent = current ? current.instruction : "Alle onderdelen zijn gemonteerd.";

  const hotspots = $("bikeHotspots");
  hotspots.innerHTML = "";
  PARTS.forEach(part => {
    const spot = document.createElement("button");
    const done = state.mounted.has(part.id);
    const active = current?.id === part.id;
    spot.type = "button";
    spot.className = `hotspot${done ? " done" : ""}${active ? " current" : ""}`;
    spot.style.left = `${part.pos[0]}%`;
    spot.style.top = `${part.pos[1]}%`;
    spot.dataset.part = part.id;
    spot.setAttribute("aria-label", done ? `${part.label} gemonteerd` : `Montageplek ${part.label}`);
    spot.innerHTML = done ? `<span class="sprite mini ${part.sprite}" aria-hidden="true"></span><small>${part.label}</small>` : `<b>${active ? "↓" : "·"}</b>`;
    spot.addEventListener("dragover", e => { if (active) e.preventDefault(); });
    spot.addEventListener("drop", e => { e.preventDefault(); placePart(e.dataTransfer.getData("text/plain"), part.id); });
    spot.addEventListener("click", () => { if (state.selectedPart) placePart(state.selectedPart, part.id); });
    hotspots.appendChild(spot);
  });

  const grid = $("partsGrid");
  grid.innerHTML = "";
  state.trayOrder.forEach(part => {
    const used = state.mounted.has(part.id);
    const card = document.createElement("button");
    card.type = "button";
    card.draggable = !used;
    card.disabled = used;
    card.className = `part-card${used ? " used" : ""}${state.selectedPart === part.id ? " selected" : ""}`;
    card.dataset.part = part.id;
    card.innerHTML = `<span class="sprite ${part.sprite}" aria-hidden="true"></span><span>${part.label}</span><small>${used ? "Gemonteerd" : "Sleep mij"}</small>`;
    card.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", part.id); e.dataTransfer.effectAllowed = "move"; });
    card.addEventListener("click", () => { state.selectedPart = state.selectedPart === part.id ? null : part.id; renderBuild(); });
    grid.appendChild(card);
  });
}

function placePart(partId, hotspotId) {
  const current = state.mountOrder[state.mounted.size];
  const player = state.players[state.currentPlayer];
  if (!current || state.mounted.has(partId)) return;
  const feedback = $("buildFeedback");
  if (partId !== current.id || hotspotId !== current.id) {
    player.mistakes++;
    player.buildPenalty += 2000;
    feedback.textContent = `Nog niet goed. +2 seconden. Zoek de plek voor: ${current.label}.`;
    feedback.className = "feedback bad";
    beep("bad");
    return;
  }
  state.mounted.add(partId);
  state.selectedPart = null;
  feedback.textContent = `${current.label} zit goed vast.`;
  feedback.className = "feedback good";
  beep("ok");
  renderBuild();
  if (state.mounted.size === PARTS.length) {
    player.buildTime = performance.now() - state.buildStartedAt + player.buildPenalty;
    stopTimer();
    $("timer").textContent = formatTime(player.buildTime);
    setTimeout(showApproval, 650);
  }
}

function showApproval() {
  const player = state.players[state.currentPlayer];
  $("approvedPlayer").textContent = player.name;
  $("approvedPlayer").style.color = player.color;
  showScreen("approvalScreen", "Goedgekeurd");
}

function createCourse(seed, levelIndex=0) {
  const random = mulberry32(seed);
  const templates = [
    [[110,620],[280,585],[390,515],[315,445],[485,380],[590,310],[710,245],[900,175],[1090,88]],
    [[105,625],[300,565],[230,490],[420,425],[520,345],[640,305],[770,230],[955,165],[1090,88]],
    [[100,620],[245,550],[390,500],[335,420],[500,355],[620,305],[735,230],[900,158],[1095,84]],
    [[110,625],[315,580],[270,500],[445,430],[395,360],[605,305],[725,232],[920,160],[1090,90]]
  ];
  const raw = templates[Math.floor(random() * templates.length)];
  const points = raw.map((p, i) => ({
    x:p[0] + (i === 0 || i === raw.length - 1 ? 0 : (random() - .5) * 28),
    y:p[1] + (i === 0 || i === raw.length - 1 ? 0 : (random() - .5) * 14)
  }));
  const segments = [];
  let total = 0;
  for (let i = 0; i < points.length - 1; i++) {
    const dx = points[i + 1].x - points[i].x;
    const dy = points[i + 1].y - points[i].y;
    const length = Math.hypot(dx, dy);
    segments.push({ a:points[i], b:points[i + 1], dx, dy, length, start:total });
    total += length;
  }
  const course = {
    seed, points, segments, total, halfWidth:72,
    levelIndex, levelName:LEVEL_NAMES[levelIndex] || `Level ${levelIndex + 1}`,
    distanceKm:LEVEL_DISTANCE_KM, lengthMultiplier:1.25,
    checkpoints:[.44 + (levelIndex % 3) * .06],
    trafficLights:levelIndex >= 5
      ? [{progress:levelIndex % 2 ? .22 : .28},{progress:levelIndex % 2 ? .73 : .78}]
      : [{progress:levelIndex % 2 ? .70 : .26}],
    bridge:{start:.47,end:.57},
    obstacles:[], scenery:[],
    questionOrder:[]
  };
  let bridgeProgress=.52,bridgeDistance=Infinity;
  for(let i=0;i<=100;i++){
    const progress=i/100;
    const distance=Math.abs(pointAt(course,progress).y-310);
    if(distance<bridgeDistance){bridgeDistance=distance;bridgeProgress=progress;}
  }
  course.bridge={start:Math.max(.05,bridgeProgress-.045),end:Math.min(.95,bridgeProgress+.045)};
  const obstacleProgress = levelIndex < 3 ? [.17,.64,.86] : [.12,.34,.66,.88];
  obstacleProgress.forEach((progress, i) => {
    const p = pointAt(course, progress);
    const offset = (random() - .5) * 82;
    course.obstacles.push({
      x:p.x - Math.sin(p.angle) * offset, y:p.y + Math.cos(p.angle) * offset,
      id:i, radius:i % 3 === 0 ? 16 : 13, type:["cone","puddle","barrier","crate"][Math.floor(random() * 4)]
    });
  });
  return course;
}

function pointAt(course, progress) {
  const target = Math.max(0, Math.min(1, progress)) * course.total;
  const seg = course.segments.find(s => target <= s.start + s.length) || course.segments.at(-1);
  const t = Math.max(0, Math.min(1, (target - seg.start) / seg.length));
  return { x:seg.a.x + seg.dx*t, y:seg.a.y + seg.dy*t, angle:Math.atan2(seg.dy, seg.dx) };
}

function nearestOnCourse(course, x, y) {
  let best = { distance:Infinity, progress:0, x:0, y:0 };
  course.segments.forEach(seg => {
    const length2 = seg.length * seg.length;
    const t = Math.max(0, Math.min(1, ((x-seg.a.x)*seg.dx + (y-seg.a.y)*seg.dy) / length2));
    const px = seg.a.x + seg.dx*t;
    const py = seg.a.y + seg.dy*t;
    const distance = Math.hypot(x-px, y-py);
    if (distance < best.distance) best = { distance, progress:(seg.start + seg.length*t)/course.total, x:px, y:py };
  });
  return best;
}

function startRide() {
  const player = state.players[state.currentPlayer];
  player.racePenalty = 0;
  state.currentLevel = 0;
  state.lightPoints = 0;
  state.rearLightSelected = false;
  state.rearLightMounted = false;
  state.raceStartedAt = performance.now();
  state.lastFrame = performance.now();
  state.challenge = null;
  state.keys.clear();
  $("riderName").textContent = player.name;
  $("riderName").style.color = player.color;
  $("raceTurnNumber").textContent = `${state.currentPlayer + 1} VAN ${state.players.length}`;
  $("levelText").textContent = `1 / ${LEVEL_COUNT}`;
  $("distanceText").textContent = `0,0 / ${LEVEL_COUNT} km`;
  $("lightPointsText").textContent = `0 / ${LEVEL_COUNT}`;
  $("routeProgressBar").style.width = "0%";
  $("penaltyText").textContent = "0 sec";
  $("challengePanel").classList.add("hidden");
  $("levelPanel").classList.add("hidden");
  $("trafficAlert").className = "traffic-alert hidden";
  showScreen("raceScreen", "Fietsen");
  startTimer(() => performance.now() - state.raceStartedAt + player.racePenalty);
  startLevel(0);
  cancelAnimationFrame(state.animation);
  state.animation = requestAnimationFrame(raceFrame);
}

function startLevel(levelIndex) {
  state.currentLevel = levelIndex;
  state.course = state.levelCourses[levelIndex];
  const start = pointAt(state.course, 0);
  state.bike = {
    x:start.x, y:start.y, angle:start.angle, speed:0, progress:0, offset:0,
    safeProgress:0, immuneUntil:0, asked:new Set(), hitObstacles:new Set(), levelComplete:false,
    lights:state.course.trafficLights.map(light => ({...light,state:"red",triggered:false,stopped:false,passed:false,violated:false,redUntil:0}))
  };
  state.challenge = null;
  state.keys.clear();
  state.lastFrame = performance.now();
  $("levelText").textContent = `${levelIndex + 1} / ${LEVEL_COUNT}`;
  $("levelPanel").classList.add("hidden");
  $("trafficAlert").className = "traffic-alert hidden";
  showRaceMessage(`Level ${levelIndex + 1}: ${state.course.levelName}. Houd ↑ ingedrukt.`, 3000);
  drawCourse();
}

function raceFrame(now) {
  if (!state.bike) return;
  const dt = Math.min(.05, (now - state.lastFrame) / 1000);
  state.lastFrame = now;
  updateBike(dt, now);
  if (state.bike) {
    drawCourse();
    state.animation = requestAnimationFrame(raceFrame);
  }
}

function updateBike(dt, now) {
  const bike = state.bike;
  if (!bike || state.challenge) return;
  const maxSpeed = 132;
  if (state.keys.has("ArrowUp")) bike.speed = Math.min(maxSpeed, bike.speed + 220*dt);
  else bike.speed = Math.max(0, bike.speed - 8*dt);
  if (state.keys.has("ArrowDown")) bike.speed = Math.max(0, bike.speed - 270*dt);
  const sideways = 105 * dt * (.40 + bike.speed/maxSpeed);
  if (state.keys.has("ArrowLeft")) bike.offset -= sideways;
  if (state.keys.has("ArrowRight")) bike.offset += sideways;
  bike.progress = Math.min(1, bike.progress + bike.speed*dt/(state.course.total*state.course.lengthMultiplier));
  syncBikePosition();

  const roadLimit=state.course.halfWidth-13;
  if (Math.abs(bike.offset)>roadLimit) {
    bike.offset=Math.sign(bike.offset)*roadLimit;
    syncBikePosition();
    if(now>bike.immuneUntil) applyCoursePenalty("Je raakte de berm. +2 seconden.",2000);
  }
  updateTrafficLights(now);
  const obstacle=state.course.obstacles.find(o=>!bike.hitObstacles.has(o.id)&&Math.hypot(bike.x-o.x,bike.y-o.y)<o.radius+11);
  if(obstacle){
    bike.hitObstacles.add(obstacle.id);
    bike.speed=Math.max(24,bike.speed*.45);
    bike.offset=Math.max(-roadLimit,Math.min(roadLimit,bike.offset+(bike.offset>=0?-24:24)));
    syncBikePosition();
    applyCoursePenalty("Hindernis geraakt. Je kunt verder. +2 seconden.",2000);
  }

  if (bike.progress > bike.safeProgress + .02) bike.safeProgress = bike.progress;

  state.course.checkpoints.forEach((checkpoint, index) => {
    if (bike.progress >= checkpoint && !bike.asked.has(index)) {
      bike.asked.add(index);
      openChallenge(index);
    }
  });
  const overallProgress = (state.currentLevel + bike.progress) / LEVEL_COUNT;
  const travelled = overallProgress * LEVEL_COUNT * LEVEL_DISTANCE_KM;
  $("distanceText").textContent = `${travelled.toFixed(1).replace(".",",")} / ${LEVEL_COUNT} km`;
  $("routeProgressBar").style.width = `${Math.min(100,overallProgress*100)}%`;

  if (bike.progress >= .995) completeLevel();
}

function completeLevel() {
  const bike = state.bike;
  if (!bike || bike.levelComplete) return;
  bike.levelComplete = true;
  bike.speed = 0;
  state.lightPoints = state.currentLevel + 1;
  $("lightPointsText").textContent = `${state.lightPoints} / ${LEVEL_COUNT}`;
  $("routeProgressBar").style.width = `${state.lightPoints * 10}%`;
  beep("ok");
  if (state.lightPoints === LEVEL_COUNT) {
    showRearLightReward();
    return;
  }
  state.challenge = { kind:"level" };
  $("levelCompleteTitle").textContent = `Level ${state.currentLevel + 1} gehaald!`;
  $("levelCompleteText").textContent = `Goed gedaan. Je hebt ${state.lightPoints} van de ${LEVEL_COUNT} lichtpunten.`;
  $("nextLevelBtn").textContent = `Start level ${state.currentLevel + 2}`;
  $("levelPanel").classList.remove("hidden");
}

function nextLevel() {
  if (state.currentLevel >= LEVEL_COUNT - 1) return;
  startLevel(state.currentLevel + 1);
}

function syncBikePosition() {
  if (!state.bike) return;
  const p = pointAt(state.course,state.bike.progress);
  state.bike.angle = p.angle;
  state.bike.x = p.x - Math.sin(p.angle)*state.bike.offset;
  state.bike.y = p.y + Math.cos(p.angle)*state.bike.offset;
}

function updateTrafficLights(now) {
  const bike = state.bike;
  for (const light of bike.lights) {
    if (light.passed) continue;
    if (!light.triggered && bike.progress >= light.progress - .10) {
      light.triggered = true;
      light.state = "red";
      light.redUntil = now + 2800;
      showTrafficAlert("red","ROOD — REM EN STOP!");
      showRaceMessage("Verkeerslicht op rood. Stop vóór de witte streep.",2300);
    }
    if (!light.triggered) continue;
    if (light.state === "red") {
      if (bike.speed <= 3 && bike.progress < light.progress - .004) {
        light.stopped = true;
        $("trafficText").textContent = "GOED GESTOPT — WACHT";
      }
      if (bike.progress >= light.progress - .002 && !light.stopped && !light.violated) {
        light.violated = true;
        light.state = "green";
        applyCoursePenalty("Je reed door rood. Je kunt verder. +3 seconden.",3000);
        showTrafficAlert("green","DOOR ROOD — +3 SEC");
      }
      if (light.stopped && now >= light.redUntil) {
        light.state = "green";
        showTrafficAlert("green","GROEN — RIJD DOOR!");
        beep("ok");
      }
    }
    if (light.state === "green" && bike.progress > light.progress + .015) {
      light.passed = true;
      $("trafficAlert").className = "traffic-alert hidden";
    }
    break;
  }
}

function showTrafficAlert(stateName,text) {
  $("trafficAlert").className = `traffic-alert ${stateName}`;
  $("trafficText").textContent = text;
}

function applyCoursePenalty(message,penalty=2000) {
  const player = state.players[state.currentPlayer];
  player.racePenalty += penalty;
  player.mistakes++;
  state.bike.immuneUntil = performance.now() + 1000;
  $("penaltyText").textContent = `${player.racePenalty/1000} sec`;
  showRaceMessage(message, 1900);
  beep("bad");
}

function openChallenge(checkpointIndex) {
  const player = state.players[state.currentPlayer];
  const orderIndex = (state.currentPlayer * LEVEL_COUNT + state.currentLevel + checkpointIndex) % QUESTIONS.length;
  const question = QUESTIONS[state.questionOrder[orderIndex]];
  state.challenge = { kind:"question", question, checkpointIndex };
  state.bike.speed = 0;
  $("challengeType").textContent = question.type;
  $("challengePlayer").textContent = player.name;
  $("challengePlayer").style.color = player.color;
  $("challengeQuestion").textContent = question.q;
  $("challengeIcon").className = `sprite large ${question.icon}`;
  $("challengeFeedback").textContent = "";
  $("challengeFeedback").className = "feedback";
  const answers = $("answerButtons");
  answers.innerHTML = "";
  question.answers.forEach((answer, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-btn";
    button.textContent = answer;
    button.addEventListener("click", () => answerChallenge(index));
    answers.appendChild(button);
  });
  $("challengePanel").classList.remove("hidden");
}

function answerChallenge(index) {
  if (!state.challenge || state.challenge.kind !== "question") return;
  const { question } = state.challenge;
  const player = state.players[state.currentPlayer];
  const buttons = [...$("answerButtons").querySelectorAll("button")];
  if (index !== question.correct) {
    player.racePenalty += 3000;
    player.mistakes++;
    $("penaltyText").textContent = `${player.racePenalty/1000} sec`;
    $("challengeFeedback").textContent = `Niet goed. +3 seconden. Hint: ${question.hint}`;
    $("challengeFeedback").className = "feedback bad";
    buttons.forEach(button => button.disabled = true);
    setTimeout(() => buttons.forEach(button => button.disabled = false), 900);
    beep("bad");
    return;
  }
  $("challengeFeedback").textContent = question.type === "PECH" ? "Goed gerepareerd! Je mag verder." : "Goed antwoord! Je mag verder.";
  $("challengeFeedback").className = "feedback good";
  buttons.forEach(button => button.disabled = true);
  beep("ok");
  setTimeout(() => { $("challengePanel").classList.add("hidden"); state.challenge = null; }, 500);
}

function showRearLightReward() {
  cancelAnimationFrame(state.animation);
  state.animation = null;
  state.keys.clear();
  state.bike = null;
  state.challenge = { kind:"rear-light" };
  const player = state.players[state.currentPlayer];
  $("rearLightPlayer").textContent = player.name;
  $("rearLightPlayer").style.color = player.color;
  $("rearLightFeedback").textContent = "";
  $("rearLightFeedback").className = "feedback";
  $("rearLightPart").className = "rear-light-part";
  $("rearLightPart").disabled = false;
  $("rearLightTarget").className = "rear-light-target";
  $("rearLightTarget").innerHTML = "<b>LEGE PLEK</b><small>Achterlicht</small>";
  renderRewardBikeParts();
  showScreen("rearLightScreen", "Achterlicht monteren");
}

function renderRewardBikeParts() {
  const wrap = $("rewardBikeParts");
  wrap.innerHTML = "";
  PARTS.forEach(part => {
    const mounted = document.createElement("span");
    mounted.className = `reward-mounted-part sprite mini ${part.sprite}`;
    mounted.style.left = `${part.pos[0]}%`;
    mounted.style.top = `${part.pos[1]}%`;
    wrap.appendChild(mounted);
  });
}

function selectRearLight() {
  if (state.rearLightMounted) return;
  state.rearLightSelected = !state.rearLightSelected;
  $("rearLightPart").classList.toggle("selected", state.rearLightSelected);
  $("rearLightFeedback").textContent = state.rearLightSelected ? "Achterlicht gekozen. Tik nu op de lege plek." : "";
}

function mountRearLight() {
  if (state.rearLightMounted) return;
  state.rearLightMounted = true;
  state.rearLightSelected = false;
  $("rearLightPart").className = "rear-light-part mounted";
  $("rearLightPart").disabled = true;
  $("rearLightTarget").className = "rear-light-target mounted";
  $("rearLightTarget").innerHTML = '<img src="assets/rear-light.png" alt="Achterlicht gemonteerd"><strong>GOED GEMONTEERD</strong>';
  $("rearLightFeedback").textContent = "Het achterlicht zit goed vast. De fiets is nu helemaal klaar!";
  $("rearLightFeedback").className = "feedback good";
  state.challenge = null;
  beep("ok");
  setTimeout(finishTurn, 1300);
}

function finishTurn() {
  cancelAnimationFrame(state.animation);
  state.animation = null;
  stopTimer();
  state.keys.clear();
  const player = state.players[state.currentPlayer];
  player.raceTime = performance.now() - state.raceStartedAt + player.racePenalty;
  player.totalTime = player.buildTime + player.raceTime;
  state.bike = null;
  $("trafficAlert").className = "traffic-alert hidden";
  $("timer").textContent = formatTime(player.totalTime);
  beep("ok");
  if (state.currentPlayer === state.players.length - 1) {
    showResults();
    return;
  }
  $("finishedPlayer").textContent = player.name;
  $("finishedPlayer").style.color = player.color;
  $("turnSummary").textContent = `10 levels gehaald · achterlicht gemonteerd · totale tijd: ${formatTime(player.totalTime)} · ${player.mistakes} fout${player.mistakes === 1 ? "" : "en"}`;
  $("nextPlayer").textContent = state.players[state.currentPlayer + 1].name;
  showScreen("betweenScreen", "Wisselen");
}

function nextTurn() {
  state.currentPlayer++;
  $("timer").textContent = "00:00.0";
  startBuildTurn();
}

function showResults() {
  const results = [...state.players].sort((a,b) => a.totalTime - b.totalTime);
  showScreen("resultsScreen", "Uitslag");
  $("podium").innerHTML = results.slice(0,3).map((p,i) => `<div class="podium-place"><span>${i===0?"🥇":i===1?"🥈":"🥉"}</span>${escapeHtml(p.name)}</div>`).join("");
  $("resultList").innerHTML = results.map((p,i) => `<div class="result-row"><b>${i+1}</b><span>${escapeHtml(p.name)}<small>8 onderdelen · 10 levels · achterlicht · ${p.mistakes} fout${p.mistakes===1?"":"en"}</small></span><b>${formatTime(p.totalTime)}</b></div>`).join("");
}

function restartWithNewRound() {
  const names = state.players.map(p => p.name);
  names.push(names.shift());
  state.round++;
  $("timer").textContent = "00:00.0";
  beginRound(names);
}

function drawCourse() {
  const canvas = $("courseCanvas");
  const ctx = canvas.getContext("2d");
  const course = state.course;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  if(routeBackground?.complete&&routeBackground.naturalWidth){
    ctx.drawImage(routeBackground,0,0,canvas.width,canvas.height);
  }else{
    const grass=ctx.createLinearGradient(0,0,0,700);grass.addColorStop(0,"#78a85b");grass.addColorStop(1,"#476f3b");ctx.fillStyle=grass;ctx.fillRect(0,0,1200,700);
  }
  ctx.fillStyle="rgba(6,28,20,.07)";ctx.fillRect(0,0,1200,700);

  const road = offsetCoursePoints(course,-157);
  drawPath(ctx,road,128,"rgba(25,33,37,.82)");
  drawPath(ctx,road,110,"#575e61");
  drawPath(ctx,road,3,"rgba(255,255,255,.78)",[18,16]);

  drawPath(ctx,course.points,162,"rgba(28,34,36,.84)");
  drawPath(ctx,course.points,146,"#8f3d35");
  drawPath(ctx,course.points,132,"#a94c42");
  drawPath(ctx,offsetCoursePoints(course,-65),3,"rgba(255,255,255,.88)");
  drawPath(ctx,offsetCoursePoints(course,65),3,"rgba(255,255,255,.88)");
  drawBridgeRails(ctx,course);
  course.checkpoints.forEach(progress => drawCheckpoint(ctx, pointAt(course, progress), state.currentLevel + 1));
  course.trafficLights.forEach((light,index) => {
    const runtime = state.bike?.lights?.[index];
    drawTrafficLight(ctx,pointAt(course,light.progress),runtime?.state || "red");
  });
  course.obstacles.forEach(obstacle => drawObstacle(ctx, obstacle));
  drawStartFinish(ctx, pointAt(course,0), false);
  drawStartFinish(ctx, pointAt(course,1), true);
  if (state.bike) drawBike(ctx, state.bike, state.players[state.currentPlayer].color);
}

function offsetCoursePoints(course,offset) {
  return course.points.map((p,index) => {
    const before = course.points[Math.max(0,index-1)];
    const after = course.points[Math.min(course.points.length-1,index+1)];
    const angle = Math.atan2(after.y-before.y,after.x-before.x);
    return {x:p.x-Math.sin(angle)*offset,y:p.y+Math.cos(angle)*offset};
  });
}

function drawRiver(ctx,course) {
  const mid = pointAt(course,(course.bridge.start+course.bridge.end)/2);
  ctx.save(); ctx.translate(mid.x,mid.y); ctx.rotate(mid.angle);
  const water = ctx.createLinearGradient(-85,0,85,0);
  water.addColorStop(0,"#347fa4");water.addColorStop(.5,"#68b9d4");water.addColorStop(1,"#2e7399");
  ctx.fillStyle=water;ctx.fillRect(-92,-850,184,1700);
  ctx.strokeStyle="rgba(255,255,255,.35)";ctx.lineWidth=3;
  for(let y=-800;y<800;y+=42){ctx.beginPath();ctx.moveTo(-55,y);ctx.quadraticCurveTo(0,y-8,55,y);ctx.stroke();}
  ctx.restore();
}

function drawBridgeRails(ctx,course) {
  const a=pointAt(course,course.bridge.start),b=pointAt(course,course.bridge.end);
  [-80,80].forEach(offset => {
    ctx.save();ctx.strokeStyle="#e1e6e8";ctx.lineWidth=8;ctx.lineCap="round";
    ctx.beginPath();ctx.moveTo(a.x-Math.sin(a.angle)*offset,a.y+Math.cos(a.angle)*offset);ctx.lineTo(b.x-Math.sin(b.angle)*offset,b.y+Math.cos(b.angle)*offset);ctx.stroke();
    ctx.strokeStyle="#58666c";ctx.lineWidth=2;ctx.setLineDash([8,7]);ctx.stroke();ctx.restore();
  });
}

function drawTree(ctx,tree) {
  ctx.fillStyle="rgba(18,55,27,.35)";ctx.beginPath();ctx.arc(tree.x+4,tree.y+5,tree.size,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#245d2f";ctx.beginPath();ctx.arc(tree.x,tree.y,tree.size,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#579848";ctx.beginPath();ctx.arc(tree.x-3,tree.y-3,tree.size*.64,0,Math.PI*2);ctx.fill();
}

function drawHouse(ctx,house) {
  const s=house.size;
  ctx.save();ctx.translate(house.x,house.y);ctx.shadowColor="rgba(0,0,0,.28)";ctx.shadowBlur=6;ctx.shadowOffsetY=4;
  ctx.fillStyle=house.color;ctx.fillRect(-s,-s*.75,s*2,s*1.5);
  ctx.fillStyle="#8b3c31";ctx.beginPath();ctx.moveTo(-s*1.2,-s*.7);ctx.lineTo(0,-s*1.45);ctx.lineTo(s*1.2,-s*.7);ctx.closePath();ctx.fill();
  ctx.shadowColor="transparent";ctx.fillStyle="#5d3927";ctx.fillRect(-4,0,8,s*.75);ctx.fillStyle="#8ed0ef";ctx.fillRect(-s*.65,-s*.42,s*.38,s*.38);ctx.fillRect(s*.27,-s*.42,s*.38,s*.38);ctx.restore();
}

function drawPath(ctx, points, width, color, dash=[]) {
  ctx.save(); ctx.lineWidth = width; ctx.strokeStyle = color; ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.setLineDash(dash);
  ctx.beginPath(); ctx.moveTo(points[0].x, points[0].y); points.slice(1).forEach(p => ctx.lineTo(p.x,p.y)); ctx.stroke(); ctx.restore();
}

function drawCheckpoint(ctx, p, number) {
  ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle);ctx.fillStyle="#ffd24a";ctx.fillRect(-6,-72,12,144);
  ctx.fillStyle="#0d2433";ctx.fillRect(-42,-98,84,26);ctx.fillStyle="white";ctx.font="bold 13px sans-serif";ctx.textAlign="center";ctx.fillText(`VRAAG ${number}`,0,-80);ctx.restore();
}

function drawTrafficLight(ctx,p,stateName) {
  ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle);
  ctx.fillStyle="rgba(255,255,255,.96)";ctx.fillRect(-5,-72,10,144);
  ctx.fillStyle="#1b292f";ctx.fillRect(-4,-96,8,24);ctx.fillRect(-31,-125,46,38);
  ctx.fillStyle=stateName==="red"?"#ff3d2e":"#4b565b";ctx.beginPath();ctx.arc(-18,-106,9,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=stateName==="green"?"#37d56f":"#4b565b";ctx.beginPath();ctx.arc(4,-106,9,0,Math.PI*2);ctx.fill();
  ctx.restore();
}

function drawObstacle(ctx, o) {
  ctx.save(); ctx.translate(o.x,o.y);
  if (o.type === "cone") {
    ctx.fillStyle="#f36b21"; ctx.beginPath(); ctx.moveTo(0,-18);ctx.lineTo(14,14);ctx.lineTo(-14,14);ctx.closePath();ctx.fill();
    ctx.fillStyle="white";ctx.fillRect(-8,-2,16,5);ctx.fillStyle="#252b2e";ctx.fillRect(-17,13,34,6);
  } else if (o.type === "puddle") {
    ctx.fillStyle="#2a6f93";ctx.beginPath();ctx.ellipse(0,0,25,13,-.2,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#72c6e8";ctx.lineWidth=3;ctx.stroke();
  } else if (o.type === "barrier") {
    ctx.fillStyle="#eceff1";ctx.fillRect(-24,-10,48,20);ctx.fillStyle="#d9482b";for(let x=-20;x<22;x+=16)ctx.fillRect(x,-10,8,20);
  } else {
    ctx.fillStyle="#9b6739";ctx.fillRect(-16,-16,32,32);ctx.strokeStyle="#633e22";ctx.lineWidth=3;ctx.strokeRect(-16,-16,32,32);ctx.beginPath();ctx.moveTo(-14,-14);ctx.lineTo(14,14);ctx.moveTo(14,-14);ctx.lineTo(-14,14);ctx.stroke();
  }
  ctx.restore();
}

function drawStartFinish(ctx, p, finish) {
  ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(p.angle); ctx.fillStyle = finish ? "#fff" : "#ffd24a"; ctx.fillRect(-6,-73,12,146);
  ctx.fillStyle = "#0d2433"; ctx.fillRect(-42,-100,84,27); ctx.fillStyle = finish ? "#fff" : "#ffd24a"; ctx.font="900 14px sans-serif";ctx.textAlign="center";ctx.fillText(finish?"FINISH":"START",0,-81);ctx.restore();
}

function drawBike(ctx, bike, color) {
  ctx.save(); ctx.translate(bike.x,bike.y); ctx.rotate(bike.angle);
  ctx.fillStyle=color;ctx.globalAlpha=.9;ctx.beginPath();ctx.ellipse(0,0,40,24,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
  if(cyclistImage?.complete&&cyclistImage.naturalWidth) ctx.drawImage(cyclistImage,-42,-24,84,48);
  else {ctx.fillStyle="#151a1d";ctx.fillRect(-28,-7,56,14);ctx.fillStyle=color;ctx.beginPath();ctx.arc(0,0,13,0,Math.PI*2);ctx.fill();}
  ctx.strokeStyle="white";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(38,-11);ctx.lineTo(50,0);ctx.lineTo(38,11);ctx.stroke();
  ctx.restore();
}

function showRaceMessage(message, duration=1600) {
  clearTimeout(state.messageTimer);
  $("raceMessage").textContent = message;
  $("raceMessage").classList.add("show");
  state.messageTimer = setTimeout(() => $("raceMessage").classList.remove("show"), duration);
}

document.addEventListener("keydown", e => {
  if (!["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.key)) return;
  if ($("raceScreen").classList.contains("active")) e.preventDefault();
  state.keys.add(e.key);
});
document.addEventListener("keyup", e => state.keys.delete(e.key));
window.addEventListener("blur", () => state.keys.clear());

$("addPlayerBtn").addEventListener("click", addPlayer);
$("startBuildBtn").addEventListener("click", startFromSignup);
$("startRideBtn").addEventListener("click", startRide);
$("nextLevelBtn").addEventListener("click", nextLevel);
$("nextTurnBtn").addEventListener("click", nextTurn);
$("restartBtn").addEventListener("click", restartWithNewRound);
$("rearLightPart").addEventListener("click", selectRearLight);
$("rearLightPart").addEventListener("dragstart", event => {
  event.dataTransfer.setData("text/plain", "achterlicht");
  event.dataTransfer.effectAllowed = "move";
});
$("rearLightTarget").addEventListener("dragover", event => event.preventDefault());
$("rearLightTarget").addEventListener("drop", event => {
  event.preventDefault();
  if (event.dataTransfer.getData("text/plain") === "achterlicht") mountRearLight();
});
$("rearLightTarget").addEventListener("click", () => {
  if (state.rearLightSelected) mountRearLight();
  else {
    $("rearLightFeedback").textContent = "Kies eerst het achterlicht.";
    $("rearLightFeedback").className = "feedback bad";
  }
});
$("soundBtn").addEventListener("click", () => {
  state.sound = !state.sound;
  $("soundBtn").textContent = state.sound ? "🔊" : "🔇";
  $("soundBtn").setAttribute("aria-label", state.sound ? "Geluid uitzetten" : "Geluid aanzetten");
});

state.players = [{name:""},{name:""}];
renderPlayerInputs();
