# Fietstechniek Race

Interactief klassikaal spel voor leerlingen van ongeveer 13 jaar in het Praktijkonderwijs.

## Zelf aanpassen

De website bestaat uit drie gewone bronbestanden:

- `index.html` bevat de schermen en teksten.
- `assets/style.css` bepaalt kleuren, maten en vormgeving.
- `assets/app.js` bevat het spel, de 8 montageopdrachten, vragen, route en puntentelling.

Afbeeldingen staan ook in de map `assets`.

Belangrijke realistische afbeeldingen:

- `assets/bike-frame-workshop.png`: het kale fietsframe in de werkplaats.
- `assets/dutch-route-background.png`: de Nederlandse woonomgeving en de vaart.
- `assets/real-cyclist-top.png`: de fietser tijdens het parcours.

De onderdelen staan bovenaan in `assets/app.js` bij `PARTS`. De vragen staan direct daaronder bij `QUESTIONS`. Pas een vraag alleen aan binnen de aanhalingstekens en laat komma's en haakjes staan.

## Op GitHub Pages zetten

1. Pak het ZIP-bestand uit.
2. Maak op GitHub een nieuwe repository.
3. Upload `index.html`, `README.md` en de volledige map `assets` naar de hoofdmap van de repository.
4. Open op GitHub `Settings` → `Pages`.
5. Kies bij `Build and deployment`: `Deploy from a branch`.
6. Kies branch `main`, map `/(root)` en klik op `Save`.

Na een paar minuten verschijnt de openbare link van de website bij GitHub Pages.

## Spelbesturing

- Pijl omhoog: vooruit fietsen.
- Pijl links/rechts: vrij naar links of rechts over het fietspad bewegen.
- Pijl omlaag: remmen en stoppen.
- De fiets draait automatisch mee met de bochten.
- Stop vóór de witte stopstreep als het verkeerslicht rood is.
- De gele vragenlijnen openen direct een vraag of reparatieopdracht.
- De lange route bestaat uit 10 verschillende levels van samen 10 kilometer.
- Elk level heeft een vraag of reparatieopdracht, verkeersregels en hindernissen.
- Na elk gehaald level verdient de leerling één lichtpunt.
- Met 10 lichtpunten ontgrendelt de leerling een realistisch achterlicht.
- De leerling moet het achterlicht zelf op de lege montageplek zetten. Daarna telt de finish.
- De afstandsbalk, levelteller en lichtpuntenteller tonen steeds de voortgang.
- Een botsing geeft tijdstraf, maar zet de leerling niet meer terug. De route blijft altijd uit te rijden.
- Iedere leerling krijgt om de beurt de werkplaats en hetzelfde parcours.
- Bij `Nog een race` worden de montagevolgorde, route en hindernissen opnieuw opgebouwd.
